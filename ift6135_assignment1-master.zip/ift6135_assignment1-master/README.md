# ift6135_assignment1

These are the jupyter notebooks for the practical part of the assignement 1. 

Team members:
- Sanae Lotfi
- Abderrahim Khalifa 
- Yann Bouteiller
- Amine Bellahsen 

The data for the problem 3 can be found in the following url:

https://drive.google.com/file/d/1d2pOl-mmnRREJ_Wt_NugBKd7iizjt5KY/view?usp=sharing

otherwise you can use the to_npy.py file to generate the data.npz file from raw images.

The data for the problem one can be found in the follwoing url:

https://drive.google.com/file/d/1D16AUrwuN4492JDXngHBpgF8uRQeZiDo/view?usp=sharing
